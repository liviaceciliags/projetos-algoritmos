strings e structs

strings 

#include <cstring>
	char nome[50];
	
	variavel = strcmp(compara, strings)
	
	if (strcmp(compara, strings) == 0)
		cout << "sao iguais "<< endl;
	
	
	strcpy (copia, string);
	comando independente;
	
	
	tamanho = strlen(retorna o tamnho da string);
	
	
	struct dados
	{
		uma variavel que armazena varias variaveis 
	};
	
	dados alunos[50]; 	
		