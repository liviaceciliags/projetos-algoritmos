#include <iostream>
#include <cstring>//incluindo biblioteca

using namespace std;

int main()
{
	char classificacao1[50];
	char classificacao2[50];
	char classificacao3[50];
	char classificacao4[50];
	
	cin.getline(classificacao, 50);
	
	
	
	
	
	/*int tam;
	strcpy(nome, "Marco Aurelio");//copiando uma string para outra 
									//e ja inclui \0
									//entre aspas duplas 
									//uma letra = 'L'
	strcpy(nome1,nome);	
			//copiando uma outra string 					
	tam = strlen(nome);
	
		cout << nome1 << endl;
		cout << "Tamanho = " <<tam << endl;*/
	

	return 0;
}
