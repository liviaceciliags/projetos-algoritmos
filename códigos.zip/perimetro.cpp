#include <iostream>
using namespace std;

int main (){
	
	int X, Y, perimetro;
	
	cin >> X >> Y;
	
	perimetro = X*2+Y*2;
	
	cout << perimetro << endl;
	
	return 0;
}