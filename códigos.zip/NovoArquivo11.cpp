#include <iostream>
using namespace std;
int main ()
{
	int vetor[100];
	int i;
	int X = 1;
	int aux;
	int u;
	for (i = 0; X != 0; i++ )
	{
		cout << "Digite um valor a ser armazenado no vetor posicao " << i << endl;
		cin >> X;
		vetor[i] = X;
	}
	cout << "Valor a ser encontrado: " << endl;
	cin >> aux;
	X = 1;
	for (i = 0; X != 0; i++ )
	{
		X = vetor[i];
		if ( X == 0)
			break;
		if (X == aux)
		{
			cout << "Elemento " << X << " encontrado na posicao " << i << endl;
			X = 0;
			u = 0;
		}
		else
			u = 1;
	}
	if (u == 1 )
		cout << "Elemento " << aux << " nao foi encontrado" << endl;
	return 0;
}

