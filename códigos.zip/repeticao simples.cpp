#include <iostream>

using namespace std;


int main()
{
	int i;//(contador geral)
	/*int N;//(n�mero de repeti��es)

	cin >> N;*/
//i inicia em  50 e vai ate 1 
	for(i = 50; i >=1 ; i--)//i esta sendo decrementado
							// (pelo comando --)
	{
		cout  << i << endl;//printa i na tela 
	}
	return 0;
}
