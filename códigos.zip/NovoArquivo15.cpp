#include <iostream>

using namespace std;

int main ()
{
	int vetor[100];
	int i;
	int X = 1;
	int aux;
	int u;


	for (i = 0; X != 0; i++ )
	{
		cin >> X;
		vetor[i] = X;

	}
	cout << vetor[i]<< endl;
	return 0;
}
