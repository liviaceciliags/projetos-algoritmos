#include <iostream>

using namespace std;

int main ()
{
	int n;
	int i;

	cin >> n;
	for ( i = 1; i <= n; i = i + 2)
	{
			cout << i << " " ;
	}
	return 0;
}
