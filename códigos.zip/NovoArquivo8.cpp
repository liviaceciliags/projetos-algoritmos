#include <iostream>
using namespace std;
 
int main() {
 
   int x, y, PROD; 
   
   cin >> x  >> y;
   
   PROD =x*y;
   
   cout <<"PROD = " << PROD << endl;
 
    return 0;
}