#include <iostream>

using namespace std;

int main()
{
	int n;

	do
	{
		cout << "digite um codigo" << endl;
		cout << "1 - Abacaxi" << endl;
		cout << "2 - predio" << endl;
		cout << "3 - sair" << endl;
		cin>>n;
		switch(n)
		{
		case 1:
			cout << "abacaxi" << endl;
			break;
		case value:
			2;
			cout << "predia" << endl;
		default:
			break;
		}

	}
	while (n !=0);
	

	return 0;
}
