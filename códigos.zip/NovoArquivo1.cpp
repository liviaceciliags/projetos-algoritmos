#include <iostream>
#include <list>

using namespace std;

int main(){
	list<int>lista;
	list<int>::iterator p;
	bool verifica;
	int valor; //aux pra leitura
	int X, Y;
	do{
		cin >> valor;
		if(valor != -1)
			lista.push_front(valor);
		
	}while(valor != -1);
	
	cin >> X >> Y;
	
	verifica = false;
    p = lista.begin();// p recebe a posi��o inicial
    while (!verifica)
    {
        if (*p == X)//se o elemento armazenado na posi��o p for igual a X
        {
            p++;
            lista.insert(p, Y);//fun��o insert p/ inserir na lsita
            verifica = true;
        }
        p++;//incrementando em p
    }
    while (!lista.empty())
    {
        cout << lista.front() << " ";
        lista.pop_front();//remove o elemento da frente
    }
	return 0; 
}