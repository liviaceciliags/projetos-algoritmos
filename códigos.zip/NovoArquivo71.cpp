#include <iostream>

using namespace std;

int main()
{
	/*int a = 25;
	int *pa = &a;
	int b = *pa+ a;
	cout  << b;*/
	int x = 4;
	--x;
	cout << x;
	return 0;
}