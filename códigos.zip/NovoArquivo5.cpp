#include <iostream>

using namespace std;

int main()
{
	int idade [10];
	int i;
	int N;
	int maiorIdade = 0;
	int soma = 0;
	double media;
	

/*	idade [0] = 23;
	idade [1] = 12;
	idade [2] = 34;*/

	cin >> N;

	for (i = 0; i < N; i++)
		cin >> idade[i];
		
	
	for (i = 0; i < N; i++)
	{
		if (idade[i] > maiorIdade)
			maiorIdade = idade[i];
	}
	
	for (i = 0; i < N; i++)
		soma +=  idade[i];
	
	media = (double)soma/N;
	
	cout << maiorIdade << endl;
	cout << media << endl;
	
	return 0;
}
