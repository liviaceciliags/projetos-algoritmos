#include <iostream>

using namespace std;

int main ()
{
	int vetor[100];
	int N = 1;
	int i;
	int X;
	int tab;

	cin >> X;

	N = 10;
	for ( i = 0; i <= N; i++)
	{
		vetor[i] = i;
		tab = vetor[i] * X;
		cout << X << " x " << vetor[i] << " = " << tab << endl;
	}

	return 0;
}
