#inlcude <iostream>

using namespace std;

int main ()
{
	int N;


	cin >> N;

	for (int i = 0; i < N; i++)//� conhecido "atribuido o numero de repeticoes necessarias
	{
		cout << i << endl;
	}



	return 0;
}
/* while == enqunto a expressao 
for verdadeira o comando sera repetido* /