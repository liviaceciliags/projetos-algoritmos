#include <iostream>

using namespace std;

int main ()
{
	int N; //numeros de votos
	int voto [1000];
	int sim = 0;
	int nao = 0;
	int i;
	double totals;
	double totaln;

	cin >> N;

	for (i = 0; i < N; i++)
		cin >> voto[i];
	for (i = 0; i < N; i++)
	{
		if (voto[i] == 1)
			sim++;
		if (voto[i] == -1)
			nao++;
	}

	totaln = N  - sim;
	totals = N -  nao;

	if (totals > totaln)
		cout << "A maioria gostou" << endl;
	else if (totals < totaln)
		cout << "A maioria nao gostou" << endl;
	else
		cout << "Deu empate" << endl;
	return 0;
}
