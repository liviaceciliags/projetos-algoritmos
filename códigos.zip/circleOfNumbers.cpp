#include <iostream>


using namespace std;

int main()
{
    int N,X, firtsNumber;
    
    
    cin >> N >> X;
    
    if ((4 <= N <=20) && (0 <= X < N)){
    	
		function circleOfNumbers(N, firstNumber) {
		return (N / 2 + firstNumber) % N;
	}
		
		cout << oposto;	
		
	}
    
    return 0;

}