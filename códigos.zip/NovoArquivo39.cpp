#include <iostream>

using namespace std;

int primo (int x)
{
	int aux;
	int div;

	for(aux = 1 ; aux <= x ; aux++)
	{
		if(x % aux == 0)
			div++;
	}
	if(div == 2)
		return 2;
	else
		return 3;
}

int main()
{
	int x, num;

	cin >> x; 
	num = primo(x);

	if (num == 2 )
		cout << "Primo" << endl;
	else
		cout << "Not" << endl;
	return 0;
}
