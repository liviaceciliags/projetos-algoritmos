#include <iostream>
using namespace std;

int main () 
{
	int x;
	
	x = 18; 
	
	cout << "Meu nome eh Livia Cecilia " << "eu tenho: " << x << " anos" << endl;
	return 0;
}

