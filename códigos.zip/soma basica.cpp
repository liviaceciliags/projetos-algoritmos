#include <iostream>
using namespace std;

int main() {
 
    int A;
	int B;
    int X;
    
    cin >> A >> B;
    X = A + B;
    
    cout << "X = " << X << endl;
 
    return 0;
}