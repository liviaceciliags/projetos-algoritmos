#include <iostream>

using namespace std;


int main()
{
	int i;//(contador geral)
	int N;//(n�mero de repeti��es)

	cin >> N;

	for(i = 0; i < N; i++)
	{
		cout << "o for j� rodou" << N << endl;
	}
	return 0;
}
