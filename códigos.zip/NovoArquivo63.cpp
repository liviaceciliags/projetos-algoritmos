#include <iostream>

using namespace std;

int main()
{
	int valor1;
	int valor2;
	int resultado;
	
	cin >> valor1;
	cin >> valor2; 
	
	resultado = valor1+valor2;
	cout << resultado << endl;
	
	resultado = valor1 - valor2;
	cout << resultado << endl;
	
	resultado = valor1*valor2;
	cout << resultado << endl;
	
	resultado = valor1/valor2;
	cout << resultado << endl;
	

	return 0;
}