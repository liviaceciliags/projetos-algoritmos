#include <iostream>

using namespace std;

int main ()
{
	int i; //contador
	int 
	
	return 0;
}