#include <iostream>


using namespace std;

int main ()
{
	int N; //numero de usuarios
	int amigos[100]; //numero de contato
	int maior = 0;
	int menor = 1000;
	int i; //contador

	cin >> N;

	for (i = 0; i < N; i++)
		cin >> amigos[i];


	for (i = 0; i < N; i++)
	{
		if (amigos[i] > maior)
			maior = amigos[i];
		if (amigos[i] < menor)
			menor = amigos[i];
	}
	cout << "Menor numero de contatos: " << menor << endl;
	cout << "Maior numero de contatos: " << maior << endl;
	return 0;
}
