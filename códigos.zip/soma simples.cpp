#include <iostream> 
using namespace std;

int main()
{
	int x;
	int y;
	int m;
	
	x = 2;
	y = 7;
	m = x+y;
	
	cout << m << endl;
	return 0;

}