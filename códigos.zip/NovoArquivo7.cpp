#include <iostream>
 
using namespace std;
 
int main() {
 
    int A;
    int B;
    int SOMA;
    
    cin >> A >> B;
    
    SOMA = A + B;
    
    cout <<"SOMA = "<< SOMA << endl;
 
    return 0;
}