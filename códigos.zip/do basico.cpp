#include <iostream>

using namespace std;

int main()
{
	int idade;
	/*do//faz e checa depois 
	{
		cout << "Digite sua idade." << endl;
		cin >> idade;
		cout << "Idade: " << idade << endl;
	}
	while (idade >= 0);//depois verifica 
	*/

return 0;
}


/*
int n;
n = -1;
do
{

}
while (n !=- 1);
return 0;*/

