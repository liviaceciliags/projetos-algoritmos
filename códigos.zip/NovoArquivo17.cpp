#include <iostream>

using namespace std;

int main ()
{
	int N;
	int vetor[1000];
	int i;
	int x;
	int aux = 0;
	cin >> N;

	for (i = 0; i < N; i++)
	{
		cin >> x;
		vetor[i] = x;
	}
	for (i = 0; i < N;  i++)
	{
		if( vetor[i] < 0 )
		{
			vetor[i] = 0;
			aux ++;
		}
		cout << vetor[i] << " ";
	}
	cout << endl;
	cout << aux << endl;
	return 0;
}
