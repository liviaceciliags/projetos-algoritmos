#include <iostream>

using namespace std;

int main()
{
	int valor;
	int resultado;
	
	cin >> valor;
	
	resultado = valor*0;
	cout << resultado << endl;
	resultado = valor*1;
	cout << resultado << endl;
	resultado = valor*2;
	cout << resultado << endl;
	resultado = valor*3;
	cout << resultado << endl;
	resultado = valor*4;
	cout << resultado << endl;
	resultado = valor*5;
	cout << resultado << endl;
	resultado = valor*6;
	cout << resultado << endl;
	resultado = valor*7;
	cout << resultado << endl;
	resultado = valor*8;
	cout << resultado << endl;
	resultado = valor*9;
	cout << resultado << endl;
	resultado = valor*10;
	cout << resultado << endl;
	return 0;
}