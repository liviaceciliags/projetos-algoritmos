#include <iostream>
#include <iomanip>

using namespace std;

int main ()
{
	   double A, B, C, MEDIA;
	   
	   cout << fixed << setprecision (1);
	   
	   cin >> A >> B >> C;
   	
	   MEDIA = (A*2 + B*3 + C*5)/10;
	   
	   cout << setprecision (1) << "MEDIA = " << MEDIA << endl; 

	   return 0;
}