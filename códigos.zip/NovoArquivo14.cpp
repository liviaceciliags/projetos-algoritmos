#include <iostream>

using namespace std;

int main()
{
	int i, j; // contadores
	int nLinhas;
	
	cin>>nLinhas;

	for(i = 0; i < nLinhas; i++)
	{
		for(j = 0; j <= i; j++)
			cout << j + i <<" "<< endl;
		cout << endl;
	}
	return 0;
}
/*#include  <stdio.h>

int main()
{
    int n, i, sum=0, m;
    scanf("%d", &n);
    int arr[n];
    m = arr[0];
    for(i=0; i<n; i++){
        scanf("%d", &arr[i]);
        sum += arr[i];
        if(m<arr[i]){
            m = arr[i];
        }
    }
    printf("%d", sum%m);
  return 0;
}*/






