#include <iostream>
using namespace std;

int main()
{
    int T,F;
    
    cin >> T;
    
    if (0<=T<1000){
  		
  		F = T*1.8+32;
        cout <<F; 
        
    }
return 0;
}