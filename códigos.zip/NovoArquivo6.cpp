

#define LED3 3
#define LED4 4
#define btn5 5
#define btn7 7



void setup()
{
	pinMode (LED3, OUTPUT);
	pinMode (LED4, OUTPUT);
	pinMode (btn5, INPUT);
	pinMode (btn7, INPUT);
}
void loop()
{
	if (digitalRead (btn5) == HIGH)
	{
		delay (200);
		digitalWrite (LED3, HIGH);
		if (digitalRead (btn5) == LOW)
			delay (500);
		digitalWrite (LED3, LOW);

	}
	else if (digitalRead (btn7) == HIGH)
		delay (300);
	digitalWrite (LED4, HIGH);
	if (digitalRead (btn7) == LOW)
		delay (100);
	digitalWrite (LED4, LOW);
}

