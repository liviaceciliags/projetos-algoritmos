#include <iostream>

using namespace std;

int main()
{
	char nome [10]; //armzena at� 10 caracteres 
	
	nome[0] = 'M';
	nome[1] = 'a';
	nome[2] = 'r';
	nome[3] = 'c';
	nome[4] = 'o';
	nome[5] = '\0';

	cout << nome << endl;
	
	
	
	return 0;
}