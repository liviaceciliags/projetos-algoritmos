#include <iostream> 
using namespace std;

int main()

{

	cout << "Meu nome eh Livia, " << "meu professor de algoritmos eh legal" << endl;
	
	return 0;
}

