#include <iostream>
#include <iomanip>

using namespace std;

int main(){
	int X,Y,Z;

	cin >> X >> Y;
	
	Z=X%Y;
	
	cout <<Z << endl;
	/*cout <<"Libra: "<< libra << endl;
	cout <<"Euro: "<< euro << endl;*/
	
	return 0;
}