#include <iostream>

using namespace std;

int main ()
{
	int N; //numores de videos analisados
	int visu[100]; //numeros de visualiza�oes
	int maior = 0;
	int menor = 0;
	int i;

	cin >> N;

	for (i = 0; i < N; i++)
		cin >> visu[i];

	for (i = 0; i < N; i++)
	{
		if (visu[i] >= 10000000)
			maior++;
		if (visu[i] < 10000000)
			menor++;
	}


	cout << maior << " video(s) com mais de 10M views" << endl;
	cout << menor << " video(s) com menos de 10M views" << endl;



	return 0;
}
